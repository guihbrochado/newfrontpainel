type SocialMediaStatType = {
  url: string
  source: string
  views: number
  uniques: number
}

export const socialStats: SocialMediaStatType[] = [
  {
    url: 'htpps:/',
    source: 'Twitter',
    views: 9.2,
    uniques: 7.9,
  },
  {
    url: '.com/dashboard',
    source: 'Facebook',
    views: 7.7,
    uniques: 6.2,
  },
  {
    url: '.com/ecommerce-index',
    source: 'Instagram',
    views: 6.8,
    uniques: 5.5,
  },
  {
    url: '.com/apps/projects-overview',
    source: 'LinkedIn',
    views: 5.0,
    uniques: 4.9,
  },
  {
    url: '.com/blog/crypto/exchange',
    source: 'WhatsApp',
    views: 4.3,
    uniques: 3.3,
  },
]
