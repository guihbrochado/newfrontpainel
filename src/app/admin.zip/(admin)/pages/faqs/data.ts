type FaqType = {
  question: string
  answer: string
  icon: string
}

export const faqs: FaqType[] = [
  {
    question: 'What is Rizz?',
    answer:
      "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.",
    icon: 'iconoir:hexagon-dice',
  },
  {
    question: 'What cryptocurrency can I use to buy Rizz?',
    answer:
      "Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident.",
    icon: 'iconoir:flower',
  },
  {
    question: 'Can I trade Rizz?',
    answer:
      "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.",
    icon: 'iconoir:wolf',
  },
  {
    question: 'How buy Rizz on coin?',
    answer:
      'Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure.',
    icon: 'iconoir:magic-wand',
  },
  {
    question: 'Where can I download the wallet?',
    answer:
      "The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from 'de Finibus Bonorum et Malorum' by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.",
    icon: 'iconoir:emoji',
  },
  {
    question: 'What is Rizz?',
    answer:
      "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.",
    icon: 'iconoir:bitcoin-circle',
  },
]
