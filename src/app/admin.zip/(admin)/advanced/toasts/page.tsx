import PageMetaData from '@/components/PageMetaData'
import AllToasts from './components/AllToasts'

const Toasts = () => {
  return (
    <>
      <PageMetaData title="Toasts" />
      <AllToasts />
    </>
  )
}

export default Toasts
