import PageMetaData from '@/components/PageMetaData'
import AllAdvanceElements from './components/AllAdvanceElements'

const FormAdvance = () => {
  return (
    <>
      <PageMetaData title="Advance" />
      <AllAdvanceElements />
    </>
  )
}

export default FormAdvance
